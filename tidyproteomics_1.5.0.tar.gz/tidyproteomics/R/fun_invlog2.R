#' Inverse Log 2
#'
#' @param x Numeric value to calculate inverse log2
#'
#' @return A numeric
#'
invlog2 <- function(x) { 2^x }
