## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## -----------------------------------------------------------------------------
library(tidyproteomics)
str(hela_proteins)

