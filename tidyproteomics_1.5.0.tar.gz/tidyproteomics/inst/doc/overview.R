## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- eval = FALSE------------------------------------------------------------
#  library("tidyproteomics")
#  hela_proteins <- path_to_package_data("proteins") %>%
#    import("ProteomeDiscoverer", "proteins")
#  
#  hela_proteins %>% summary()
#  hela_proteins %>% summary(by = 'sample')
#  hela_proteins %>% summary(by = 'contamination')

