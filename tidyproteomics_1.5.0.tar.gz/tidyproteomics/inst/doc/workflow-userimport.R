## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- eval=FALSE--------------------------------------------------------------
#  url <- "https://ftp.ebi.ac.uk/pride-archive/2016/06/PXD004163/Yan_miR_Protein_table.flatprottable.txt"
#  download.file(url, destfile = "./miR_Proteintable.tsv",method = "auto")

## ---- eval=FALSE--------------------------------------------------------------
#  library(dplyr)
#  library(tidyproteomics)
#  
#  data_prot <- "miR_Proteintable.tsv" %>% import('PXD004163', 'proteins', path = "TMTOpenMS_proteins.tsv")

## ---- echo=FALSE, message=FALSE-----------------------------------------------
library(dplyr)
library(tidyproteomics)

data_prot <- "~/Local/data/tidyproteomics/PXD004163/miR_Proteintable.tsv" %>% 
  import('PXD004163', 'proteins', 
         path = "~/Local/data/tidyproteomics/PXD004163/TMTOpenMS_proteins.tsv")

## -----------------------------------------------------------------------------
data_prot

## -----------------------------------------------------------------------------
data_prot %>% plot_quantrank()

## -----------------------------------------------------------------------------
data_prot <- data_prot %>%
  subset(protein_qvalue < 0.01) %>%
  reassign(sample == 's126', .replace = 'ctrl') %>%
  reassign(sample == 's127n', .replace = 'miR191') %>%
  reassign(sample == 's127c', .replace = 'miR372') %>%
  reassign(sample == 's128n', .replace = 'miR519') %>%
  reassign(sample == 's128c', .replace = 'ctrl') %>%
  reassign(sample == 's129n', .replace = 'miR372') %>%
  reassign(sample == 's129c', .replace = 'miR519') %>%
  reassign(sample == 's130n', .replace = 'ctrl') %>%
  reassign(sample == 's130c', .replace = 'miR191') %>%
  reassign(sample == 's131', .replace = 'miR372')

data_prot

## -----------------------------------------------------------------------------
data_prot %>% plot_pca()

