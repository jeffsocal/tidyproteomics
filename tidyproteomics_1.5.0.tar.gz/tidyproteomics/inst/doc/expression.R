## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message=FALSE-----------------------------------------------------------
library("dplyr")
library("tidyproteomics")

rdata <- hela_proteins %>% 
  normalize(.method = 'loess') %>%
  expression(knockdown/control)

## -----------------------------------------------------------------------------

rdata %>% export_analysis(knockdown/control, .analysis = 'expression')

## -----------------------------------------------------------------------------

rdata %>% plot_volcano(knockdown/control)

## -----------------------------------------------------------------------------

rdata %>% plot_volcano(knockdown/control,
                       significance_column = 'p_value',
                       significance_max = 0.01,
                       log2fc_min = 2)

## -----------------------------------------------------------------------------
library(ggplot2)

rdata %>% plot_volcano(knockdown/control,
                       significance_column = 'p_value',
                       significance_max = 0.01,
                       log2fc_min = 2,
                       color_positive = 'orange',
                       color_negative = 'purple',
                       show_lines = FALSE,
                       show_fc_scale = FALSE,
                       show_pannels = FALSE,
                       labels_column = 'gene_name') +
  labs(title = "A nice volcano plot", subtitle = "with great colors")

## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)

rdata %>% plot_proportion(knockdown/control)

## -----------------------------------------------------------------------------
library(ggplot2)

rdata %>% plot_proportion(knockdown/control,
                       significance_column = 'p_value',
                       proportion_min = 0.1,
                       log2fc_min = 2,
                       color_positive = 'orange',
                       color_negative = 'purple',
                       show_lines = TRUE,
                       labels_column = 'gene_name')


