## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("tidyproteomics")

## ---- eval = FALSE------------------------------------------------------------
#  # path_to_package_data() loads data specific to this package
#  # for your project load local data
#  # example:
#  # your_proteins <- "./data/your_exported_results.xlsx" %>%
#  #   import("ProteomeDiscoverer", "proteins")
#  
#  hela_proteins <- path_to_package_data("p97KD_HCT116") %>%
#    import("ProteomeDiscoverer", "proteins") %>%
#    # change the sample labels
#    reassign('sample', 'ctl', 'control') %>%
#    reassign('sample', 'p97', 'knockdown')

## -----------------------------------------------------------------------------
hela_proteins

## -----------------------------------------------------------------------------
hela_proteins %>%
  expression(knockdown/control) %>%
  enrichment(knockdown/control, .term = 'biological_process') %>%
  enrichment(knockdown/control, .term = 'molecular_function')

## -----------------------------------------------------------------------------
hela_proteins %>% summary()

## -----------------------------------------------------------------------------
hela_proteins %>% summary(by = 'sample') 

## -----------------------------------------------------------------------------
hela_proteins %>% summary(contamination = 'CRAP') 

## -----------------------------------------------------------------------------
hela_proteins %>% summary(contamination = "ribosome") 

## -----------------------------------------------------------------------------
hela_proteins %>% summary('biological_process')

