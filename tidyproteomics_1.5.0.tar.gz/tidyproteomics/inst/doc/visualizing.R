## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("tidyproteomics")

rdata <- hela_proteins %>% normalize(.method = c("scaled", "median", "linear", "loess", "randomforest"))

rdata %>% plot_normalization()

## -----------------------------------------------------------------------------
rdata %>% plot_variation_cv()

## -----------------------------------------------------------------------------
rdata %>% plot_variation_pca()

## -----------------------------------------------------------------------------
rdata %>% plot_dynamic_range()

## -----------------------------------------------------------------------------
rdata %>% plot_heatmap()

## -----------------------------------------------------------------------------
rdata %>% plot_pca()

## -----------------------------------------------------------------------------
rdata %>% plot_pca(variables = c('PC3', 'PC4'))

