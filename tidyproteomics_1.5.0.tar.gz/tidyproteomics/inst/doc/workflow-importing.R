## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message=FALSE, warning=FALSE, eval=FALSE--------------------------------
#  library(tidyverse)
#  library(tidyproteomics)
#  
#  # download the data
#  url <- "https://data.caltech.edu/records/aevwq-2ps50/files/ProteomeDiscoverer_2.5_p97KD_HCT116_proteins.xlsx?download=1"
#  download.file(url, destfile = "./data/pd_proteins.xlsx")
#  
#  # import the data
#  data_prot <- "./data/pd_proteins.xlsx" %>% import('ProteomeDiscoverer', 'proteins')

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(tidyverse)
library(tidyproteomics)

# import the data
data_prot <- "~/Local/data/tidyproteomics/ProteomeDiscoverer_2.5/p97KD_HCT116_proteins.xlsx" %>% import('ProteomeDiscoverer', 'proteins')

data_prot

## ---- message=FALSE, warning=FALSE, eval=FALSE--------------------------------
#  library(tidyverse)
#  library(tidyproteomics)
#  
#  # download the data
#  url <- "https://data.caltech.edu/records/aevwq-2ps50/files/MaxQuant_1.6.10.43_proteinGroups.txt?download=1"
#  download.file(url, destfile = "./data/mq_proteinGroups.txt")
#  
#  # import the data
#  data_prot <- "./data/mq_proteinGroups.txt" %>% import('MaxQuant', 'proteins')

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(tidyverse)
library(tidyproteomics)

# import the data
data_prot <- "~/Local/data/tidyproteomics/MaxQuant_1.6.10.43/proteinGroups.txt" %>% import('MaxQuant', 'proteins')

data_prot

## ---- message=FALSE, warning=FALSE, eval=FALSE--------------------------------
#  library(tidyverse)
#  library(tidyproteomics)
#  
#  # download the data
#  url <- "https://data.caltech.edu/records/aevwq-2ps50/files/FragPipe_19.1_combined_protein.tsv?download=1"
#  download.file(url, destfile = "./data/fp_combined_protein.tsv")
#  
#  # import the data
#  data_prot <- "./data/fp_combined_protein.tsv" %>% import('FragPipe', 'proteins')

## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(tidyverse)
library(tidyproteomics)

# import the data
data_prot <- "~/Local/data/tidyproteomics/FragPipe_19.1/combined_protein.tsv" %>% import('FragPipe', 'proteins')

data_prot

