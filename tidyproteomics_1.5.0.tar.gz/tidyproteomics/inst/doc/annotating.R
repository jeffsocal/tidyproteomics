## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- eval=FALSE--------------------------------------------------------------
#  library(tidyverse)
#  library(tidyproteomics)
#  
#  # download the data
#  url <- "https://ftp.ebi.ac.uk/pride-archive/2016/06/PXD004163/Yan_miR_Protein_table.flatprottable.txt"
#  download.file(url, destfile = "./data/combined_protein.tsv", method = "auto")
#  
#  # import the data
#  data_prot <- "./data/combined_protein.tsv" %>% import('FragPipe', 'proteins')

## ---- echo=FALSE, warning=FALSE, message=FALSE--------------------------------
library(tidyverse)
library(tidyproteomics)

data_prot <- "~/Local/data/tidyproteomics/FragPipe_19.1/combined_protein.tsv" %>%
  import('FragPipe', 'proteins')


## ---- message=FALSE-----------------------------------------------------------
data_fasta <- "~/Local/data/fasta/uniprot_human-20398_20220920.fasta" %>% 
  tidyproteomics:::fasta_parse(as = "data.frame") %>%
  select(protein = accession, gene_name, description) %>%
  pivot_longer(
    cols = c('gene_name', 'description'),
    names_to = 'term',
    values_to = 'annotation'
  )

data_fasta %>% filter(protein %in% c('P68431', 'P62805'))


## -----------------------------------------------------------------------------
data_prot$annotations %>% filter(protein %in% c('P68431', 'P62805'))


## -----------------------------------------------------------------------------
data_new_merged <- data_prot %>% annotate(data_fasta, duplicates = 'merge')

data_new_merged$annotations %>% filter(protein %in% c('P68431', 'P62805'))


## -----------------------------------------------------------------------------
data_new_replaced <- data_prot %>% annotate(data_fasta, duplicates = 'replace')

data_new_replaced$annotations %>% filter(protein %in% c('P68431', 'P62805'))


## ---- message=FALSE-----------------------------------------------------------
data_go <- "~/Local/data/uniprot-compressed_true_download_true_fields_accession_2Creviewed_2C-2023.04.13-22.27.47.76.tsv" %>% read_tsv()

head(data_go)


## -----------------------------------------------------------------------------
data_go <- data_go %>%
  select(protein = Entry,
         molecular_function = `Gene Ontology (molecular function)`) %>%
  # separate the GO terms so we get 1/row
  separate_rows(molecular_function, sep="\\;\\s") %>%
  # remove the [GO:accession]
  mutate(molecular_function = sub("\\s\\[.+", "", molecular_function)) %>%
  # pivot to the needed format
  pivot_longer(molecular_function,
               names_to = 'term',
               values_to = 'annotation')

head(data_go)


## -----------------------------------------------------------------------------
data_new_go <- data_prot %>% annotate(data_go)

data_new_go$annotations %>% filter(protein %in% c('P68431', 'P62805'))


## ---- message=FALSE-----------------------------------------------------------
data_new_go %>% 
  subset(molecular_function == 'structural constituent of chromatin')


## ---- message=FALSE-----------------------------------------------------------
data_new_go %>% 
  subset(molecular_function %like% 'ion binding') %>% 
  expression(knockdown/control) %>% 
  enrichment(knockdown/control, 
             .term = 'molecular_function',
             .method = 'wilcoxon') %>%
  plot_enrichment(
    knockdown/control, 
    .term = 'molecular_function',
    significance_max = 1
  )


