## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("tidyproteomics")

## ---- eval = FALSE------------------------------------------------------------
#  # replace path_to_package_data("proteins") with the path to your local data.
#  # hela_proteins <- "./data/hela_export_table.xlsx" %>%
#  #    import("ProteomeDiscoverer", "proteins")
#  data_proteins <- path_to_package_data("hela_proteins") %>%
#     import("ProteomeDiscoverer", "proteins")

## ---- eval = FALSE------------------------------------------------------------
#  data_proteins <- "path_to_maxquant_project/combined/txt/proteinGroups.txt" %>%
#     import("MaxQuant", "proteins") %>%
#     reassign(field = 'sample', pattern = 'sample_1', replace = 'ko') %>%
#     reassign(field = 'sample', pattern = 'sample_2', replace = 'ko') %>%
#     reassign(field = 'sample', pattern = 'sample_3', replace = 'ko') %>%
#     reassign(field = 'sample', pattern = 'sample_4', replace = 'ko') %>%
#     reassign(field = 'sample', pattern = 'sample_5', replace = 'wt') %>%
#     reassign(field = 'sample', pattern = 'sample_6', replace = 'wt') %>%
#     reassign(field = 'sample', pattern = 'sample_7', replace = 'wt') %>%
#     reassign(field = 'sample', pattern = 'sample_8', replace = 'wt')

## ---- eval = FALSE------------------------------------------------------------
#  data_peptides <- "path_to_skyline_project/output_file_name.csv" %>%
#     import("Skyline", "peptides")

## ---- eval = FALSE------------------------------------------------------------
#  data_peptides <- "path_to_diann_project/output_file_name.csv" %>%
#     import("DIA-NN", "peptides")

## ---- eval = FALSE------------------------------------------------------------
#  data_proteins <- "path_to_data/project.mzTab" %>% import("mzTab", "proteins")

## ---- eval = FALSE------------------------------------------------------------
#  data_peptides <- "path_to_data/project.mzTab" %>% import("mzTab", "peptides")

