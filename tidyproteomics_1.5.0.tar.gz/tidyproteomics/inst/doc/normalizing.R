## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- echo=FALSE--------------------------------------------------------------
library(tidyproteomics)
library(tidyverse)

## -----------------------------------------------------------------------------
hela_proteins$identifier
hela_proteins$quantitative %>% head()

## -----------------------------------------------------------------------------
hela_peptides$identifier
hela_peptides$quantitative %>% head()

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("tidyproteomics")

## ---- message=FALSE-----------------------------------------------------------
# path_to_package_data() loads data specific to this package
# for your project load local data
# example: 
# your_proteins <- "./data/your_exported_results.xlsx" %>%
#   import("ProteomeDiscoverer", "proteins")

rdata <- hela_proteins %>% normalize(.method = c("scaled", "median", "linear", "loess", "randomforest"))

## -----------------------------------------------------------------------------
rdata %>% plot_variation_cv()

## -----------------------------------------------------------------------------
rdata %>% plot_variation_pca()

## ---- message=FALSE-----------------------------------------------------------
hela_proteins %>%
  normalize(.method = c('median', 'randomforest')) %>% 
  plot_dynamic_range()

## ---- message=FALSE-----------------------------------------------------------
rdata <- hela_proteins %>%
  normalize(description %like% 'ribosome',
            .method = c('median', 'linear', 'loess', 'svm')) 

rdata %>% plot_variation_cv()

## -----------------------------------------------------------------------------
rdata %>% plot_dynamic_range()

## -----------------------------------------------------------------------------
rdata %>% operations()

## ---- warning=FALSE, fig.height=3, fig.width=8--------------------------------
hela_proteins %>% normalize(.method = 'median') %>% plot_normalization()

