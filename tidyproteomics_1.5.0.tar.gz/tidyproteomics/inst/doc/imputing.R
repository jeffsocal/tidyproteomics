## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- echo=FALSE, message=FALSE-----------------------------------------------
library("dplyr")
library("tidyproteomics")

## -----------------------------------------------------------------------------
hela_proteins$identifier
hela_proteins$quantitative %>% head()

## -----------------------------------------------------------------------------
hela_peptides$identifier
hela_peptides$quantitative %>% head()

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("ggplot2")
library("tidyproteomics")

## ---- message=FALSE-----------------------------------------------------------
# path_to_package_data() loads data specific to this package
# for your project load local data
# example: 
# your_proteins <- "./data/your_exported_results.xlsx" %>%
#   import("ProteomeDiscoverer", "proteins")

rdata <- hela_proteins

## ---- message=FALSE-----------------------------------------------------------
w <- which(rdata$quantitative$protein == 'P06576' & rdata$quantitative$sample == 'knockdown')
rdata$quantitative <- rdata$quantitative[-w,]

## ---- message=FALSE-----------------------------------------------------------

rdata %>% 
  impute(.function = base::min, method = 'column') %>%
  subset(protein %like% "P23443|P51812|P06576") %>% 
  extract() %>%
  ggplot(aes(replicate, abundance)) +
  geom_point(aes(color=sample), size=3, alpha=.5) +
  facet_wrap(~identifier) +
  scale_y_log10(limits = c(1e4,1e9)) +
  scale_color_manual(values = c('red','blue'))

## ---- message=FALSE-----------------------------------------------------------

rdata %>% 
  impute(.function = base::min, method = 'row') %>%
  subset(protein %like% "P23443|P51812|P06576") %>% 
  extract() %>%
  ggplot(aes(replicate, abundance)) +
  geom_point(aes(color=sample), size=3, alpha=.5) +
  facet_wrap(~identifier) +
  scale_y_log10(limits = c(1e4,1e9)) +
  scale_color_manual(values = c('red','blue'))

## ---- eval=FALSE--------------------------------------------------------------
#  
#  rdata %>% impute(.function = impute.randomforest, method = 'matrix') %>%

## ---- eval=FALSE--------------------------------------------------------------
#  library(impute)
#  
#  rdata %>% impute(.function = impute.knn, method = 'matrix') %>%

