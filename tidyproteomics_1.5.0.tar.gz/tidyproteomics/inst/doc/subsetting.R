## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("tidyproteomics")

hela_proteins %>% summary('sample')

## ---- message = FALSE---------------------------------------------------------
hela_proteins %>% subset(description %like% "Ribosome") %>% summary('sample')

## -----------------------------------------------------------------------------
colnames(hela_proteins$experiments)

## -----------------------------------------------------------------------------
colnames(hela_proteins$accounting)

## -----------------------------------------------------------------------------
hela_proteins$annotations$term %>% unique()

## ---- message = FALSE---------------------------------------------------------
hela_proteins %>% subset(cellular_component %like% "nucleus") %>% summary('sample')

## ---- message = FALSE---------------------------------------------------------
hela_proteins %>% subset(match_between_runs == FALSE) %>% summary('sample')

## ---- message = FALSE---------------------------------------------------------
hela_proteins %>% subset(mum_peptides <= 1) %>% summary('sample')

## ---- message = FALSE---------------------------------------------------------
hela_proteins %>% subset(num_unique_peptides <= 1) %>% summary('sample')

## ---- message = FALSE---------------------------------------------------------
hela_proteins %>% 
  subset(cellular_component %like% "cytosol") %>% 
  summary() 

## ---- message = FALSE---------------------------------------------------------
data_kd <- hela_proteins %>% 
  subset(sample %like% "knockdown") %>% 
  normalize(.method = c('median')) %>%
  impute()

data_ct <- hela_proteins %>% 
  subset(sample %like% "control") %>% 
  normalize(.method = c('median')) %>%
  impute()

data_new <- merge(list(data_kd, data_ct), quantitative_source = 'all')

## ---- message = FALSE---------------------------------------------------------
data_new

## ---- message = FALSE---------------------------------------------------------
data_new %>% summary('sample')

## -----------------------------------------------------------------------------
data_new %>% operations()

