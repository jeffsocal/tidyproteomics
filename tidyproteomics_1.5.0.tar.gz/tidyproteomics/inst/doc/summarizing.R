## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message = FALSE---------------------------------------------------------
library("dplyr")
library("tidyproteomics")

## -----------------------------------------------------------------------------
hela_proteins

## -----------------------------------------------------------------------------
hela_proteins %>% expression(knockdown/control) %>% enrichment(knockdown/control, .term = 'biological_process')

## -----------------------------------------------------------------------------
hela_proteins %>% summary()

## -----------------------------------------------------------------------------
hela_proteins %>% summary(by = 'sample')

## -----------------------------------------------------------------------------
hela_proteins %>% summary(by = 'biological_process')

## -----------------------------------------------------------------------------
hela_proteins %>% summary(by = 'num_peptides')

## -----------------------------------------------------------------------------
hela_proteins %>% summary(by = 'match_between_runs')

## -----------------------------------------------------------------------------
hela_proteins %>% summary(contamination = 'CRAP')

## -----------------------------------------------------------------------------
hela_proteins %>% summary(contamination = 'Trypsin')

## -----------------------------------------------------------------------------
hela_proteins %>% summary(contamination = 'ribosome')

## -----------------------------------------------------------------------------
hela_proteins %>% plot_counts()

## -----------------------------------------------------------------------------
hela_proteins %>% plot_quantrank()

## -----------------------------------------------------------------------------
hela_proteins %>% plot_quantrank(display_filter = 'log2_foldchange', display_cutoff = 2)

## -----------------------------------------------------------------------------
hela_proteins %>% plot_quantrank(show_rank_scale = TRUE, limit_rank = c(1,25))

