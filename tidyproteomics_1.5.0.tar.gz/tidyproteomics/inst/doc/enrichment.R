## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1041)
options(dplyr.print_max = 10)

## ---- message=FALSE, warning=FALSE--------------------------------------------
library("dplyr")
library("tidyproteomics")

rdata <- hela_proteins %>% 
  normalize(.method = 'linear') %>%
  expression(knockdown/control) %>%
  enrichment(knockdown/control, 
             .term = 'biological_process', 
             .method = 'wilcoxon')

## -----------------------------------------------------------------------------

rdata %>% export_analysis(knockdown/control, 
                          .analysis = 'enrichment', 
                          .term = 'biological_process')

## -----------------------------------------------------------------------------

rdata %>% export_analysis(knockdown/control, 
                          .analysis = 'enrichment', 
                          .term = 'biological_process',
                          .append = 'gene_name')

## -----------------------------------------------------------------------------

rdata %>% plot_enrichment(knockdown/control, 
                          .term = 'biological_process')

